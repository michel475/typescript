export const login = (): void => {
    alert('Bem vindo') 
}