export const Rodape = () => {
    return (
        <div>
            <footer>
                Isso aqui é um Rodape
            </footer>
        </div>
    )
}