import { login } from "../../services/login"
import { Button, ChakraProvider, defaultSystem } from "@chakra-ui/react"

export const Botao = () => {
    return (
        <ChakraProvider value={defaultSystem}>
            <Button onClick={login}>
                Entrar
            </Button>
        </ChakraProvider>
    )
}