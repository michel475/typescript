import { Cabecalho } from "./Cabecalho/Cabecalho"
import { Rodape } from "./Rodape"

export const Layout = ({ children }:any) => {
    return (
        <>
        <Cabecalho/>
        {children}
        <Rodape/>
        </>
    )
}