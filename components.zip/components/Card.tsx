import { login } from "@/services/login"
import { Box, Button, Center, ChakraProvider, defaultSystem, Input } from "@chakra-ui/react"
import { Botao } from "../components/Botao/Botao"
import { Cabecalho } from "./Cabecalho/Cabecalho"

interface ICard {
}

export const Card = (/*{id, paragrafo}:ICard*/) => {
    return (
    <ChakraProvider value={defaultSystem}>
            <Box minHeight='100vh' backgroundColor='#9413dc' padding='25px'>
                <Center>
                          <Cabecalho/>
                      </Center>
                <Box backgroundColor='#FFFFFF' borderRadius='25px' padding='15px'>
                    <Center>
                        <h1>Login</h1>
                    </Center>
                    <Input placeholder='email'/>
                    <Input placeholder='password'/>
                    <Center>
                        <Botao/>
                    </Center>
                </Box>
            </Box>
   </ChakraProvider>
    )
}