import { ChakraProvider, defaultSystem, Box } from '@chakra-ui/react'

export const Cabecalho = () => {
    return (
        <ChakraProvider value={defaultSystem}>
            <Box backgroundColor='#ffffff'    borderRadius='0%' minHeight='25px'>
                Dio Banking
            </Box>
        </ChakraProvider>
    )
}